package com.rent_car.rent_car;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentCarApplicationTests {

	@Test
	void contextLoads() {
	}

}
